/*
 * EEPROM_interface.h
 *
 *  Created on: Sep 30, 2022
 *      Author: ABDELRAHMNA
 */

#ifndef HAL_HAL_EEPROM_EEPROM_INTERFACE_H_
#define HAL_HAL_EEPROM_EEPROM_INTERFACE_H_

#include "../../Helper/STD_TYPES.h"
#include "../../Helper/BIT_MATH.h"



void EEPROM_init(void);

void EEPROM_WRITE(u16 Address ,u8 Data);

void EEPROM_READ(u16 Address ,u8 *Data);
#endif /* HAL_HAL_EEPROM_EEPROM_INTERFACE_H_ */

/*
 * MOTOR_config.h
 *
 *  Created on: Sep 6, 2022
 *      Author: Abdelrahman
 */

#ifndef HAL_STEPPER_MOTOR_MOTOR_CONFIG_H_
#define HAL_STEPPER_MOTOR_MOTOR_CONFIG_H_

#define MOTOR_PORT A
#define MOTOR_PIN0 PIN0
#define MOTOR_PIN1 PIN1

#endif /* HAL_STEPPER_MOTOR_MOTOR_CONFIG_H_ */

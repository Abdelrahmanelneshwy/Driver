/*
 * UART_config.h
 *
 *  Created on: Sep 21, 2022
 *      Author: Abdelrahman
 */

#ifndef MCAL_UART_UART_CONFIG_H_
#define MCAL_UART_UART_CONFIG_H_

#define UCSRA  *((volatile u8*)0x2B)
#define UCSRB  *((volatile u8*)0x2A)
#define UCSRC  *((volatile u8*)0x40)
#define UDR    *((volatile u8*)0x2C)
#define UBRRL  *((volatile u8*)0x29)
//#define UBRRH  *((volatile u8*)0x)

/***********Registers PINS*************/
   /************ UCSRA *************/
#define RXC  7
#define TXC  6
#define UDRE 5
#define FE   4
#define DOR  3
#define PE   2
#define U2X  1
#define MPCM 0

   /************ UCSRB *************/
#define RXCIE  7
#define TXCIE  6
#define UDRIE  5
#define RXEN   4
#define TXEN   3
#define UCSZ2  2
#define RXB8   1
#define TXB8   0

   /************ UCSRC *************/
#define URSEL  7
#define UMSEL  6
#define UPM1   5
#define UPM0   4
#define USBS   3
#define UCSZ1  2
#define UCSZ0  1
#define UCPOL  0

   /************ UDR *************/
#define UDR7   7
#define UDR6   6
#define UDR5   5
#define UDR4   4
#define UDR3   3
#define UDR2   2
#define UDR1   1
#define UDR0   0

   /************ UBRRL *************/
#define UBRRL7   7
#define UBRRL6   6
#define UBRRL5   5
#define UBRRL4   4
#define UBRRL3   3
#define UBRRL2   2
#define UBRRL1   1
#define UBRRL0   0


#endif /* MCAL_UART_UART_CONFIG_H_ */

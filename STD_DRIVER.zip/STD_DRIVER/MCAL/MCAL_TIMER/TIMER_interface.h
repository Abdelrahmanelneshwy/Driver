/*
 * TIMER_interface.h
 *
 *  Created on: Sep 22, 2022
 *      Author: Abdelrahman
 */

#ifndef MCAL_TIMER_TIMER_INTERFACE_H_
#define MCAL_TIMER_TIMER_INTERFACE_H_


#include "../../Helper/STD_TYPES.h"
#include "../../Helper/BIT_MATH.h"
#include "../MCAL_DIO/DIO_interface.h"
#include "TIMER_Register.h"
#include "TIMER_config.h"

#define TMR0_CLKMC    0x01
#define TMR0_CLK_8    0x02
#define TMR0_CLK_64   0x03
#define TMR0_CLK_256  0x04
#define TMR0_CLK_1024 0x05
#define TMR0_EVENT_FE 0x06
#define TMR0_EVENT_RE 0x07

void  TMR0_voidInit(void);
void  TMR0_voidStart(u8 copy_u8Prescaler);
// SetTMR0Start
void  TMR0_voidSetTCNT0(u8 copy_u8InitValue);

u32   TMR0_u32ReadTMR0(void);

void  TMR0_voidSetNormalWithInterrupt(void (*copy_CB)(void));
//SetTMR0Compare
void  TMR0_voidSetOCR0(u8 copy_u8InitValue);

void  TMR0_voidSetCTCWithInterrupt(void (*copy_CB)(void));

void  TMR0_voidStopTMR0(void);
// Set TCCR0 =0x00
void  TMR0_voidDInit(void);

void TMR0_GenerateFastPWM(u8 copy_u8DutyCycle);

void TMR0_GeneratePhaseCorrectPWM(u8 copy_u8DutyCycle);
#endif /* MCAL_TIMER_TIMER_INTERFACE_H_ */

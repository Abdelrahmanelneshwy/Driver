#ifndef _MCAL_EXTI_INTERFACE_H_
#define _MCAL_EXTI_INTERFACE_H_

#define  INT0_PIN 0
#define  INT1_PIN 1
#define  INT2_PIN 2

#define  LOW_LEVEL   		0
#define  ANY_LOGICAL_LEVEL 	1
#define  FALLING_LEVEL 		2
#define  RISING_LEVEL		3

#include "../../Helper/STD_TYPES.h"
#include "../../Helper/BIT_MATH.h"
#include "../MCAL_DIO/DIO_interface.h"
#include "EXTI_private.h"
#include "EXTI_config.h"


void EXTI_vidInit(u8 IntPinNum, u8 ModeNum);
void EXTI_vidSetCB(u8 IntPinNum ,void(*CBFUN)(void) );







#endif

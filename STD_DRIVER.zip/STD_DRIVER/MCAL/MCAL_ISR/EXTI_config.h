#ifndef _MCAL_EXTI_CONFIG_H_
#define _MCAL_EXTI_CONFIG_H_


/*************SREG PINS*********/
#define I 7 // Global interrupt
#define T 6 //Bit Copy Storage
#define H 5 //Half Carry Flag
#define S 4 //Sign Bit
#define V 3 // Two’s Complement Overflow Flag
#define N 2 //Negative Flag
#define Z 1 //Zero Flag
#define c 0 //Carry Flag

/***************MCUCR PINS****************/

#define SE    7 // Reversed
#define SM2   6 // Reversed
#define SM1   5 // Reversed
#define SM0   4 // Reversed
#define ISC11 3 // Interrupt Sense Control 1 Bit 1
#define ISC10 2 // Interrupt Sense Control 1 Bit 0
#define ISC01 1 // Interrupt Sense Control 0 Bit 1
#define ISC00 0 // Interrupt Sense Control 0 Bit 0


/********************MCUCSR*****/
#define JTD   7 // Reversed
#define ISC2  6 // Interrupt Sense Control 2
#define JTRF  4 // Reversed
#define WDRF  3 // Reversed
#define BORF  2 // Reversed
#define EXTRF 1 // Reversed
#define PORF  0 // Reversed

#endif

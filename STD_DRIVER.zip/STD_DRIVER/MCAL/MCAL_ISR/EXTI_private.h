#ifndef _MCAL_ExTI_PRIVATE_H_
#define _MCAL_ExTI_PRIVATE_H_

#define RESET  *((volatile u8*)0x00)
#define INT0   *((volatile u8*)0x02)
#define INT1   *((volatile u8*)0x04)
#define INT2   *((volatile u8*)0x06)
#define GICI   *((volatile u8*)0x5B)
#define MCUCR  *((volatile u8*)0x55)
#define MCUCSR *((volatile u8*)0x54)
#define GIFR   *((volatile u8*)0x5A)
#define SREG   *((volatile u8*)0x5F)






#endif

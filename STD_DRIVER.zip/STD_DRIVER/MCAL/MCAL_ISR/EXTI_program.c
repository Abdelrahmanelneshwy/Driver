
#include "EXTI_interface.h"
#include "avr/interrupt.h"
#include "../../Helper/BIT_MATH.h"
void (*CB_INT0)(void);
void (*CB_INT1)(void);
void (*CB_INT2)(void);

void EXTI_vidInit(u8 IntPinNum, u8 ModeNum)
{
	SET_BIT(SREG,I);
   switch(IntPinNum)
   {
        case INT0_PIN:
        DIO_setPinDir(D, PIN2 , input);
            if(ModeNum==LOW_LEVEL)
                {   CLR_BIT(MCUCR,ISC00);
                    CLR_BIT(MCUCR,ISC01);
                }
            else if (ModeNum==ANY_LOGICAL_LEVEL)
                {
                    SET_BIT(MCUCR,ISC00);
                    CLR_BIT(MCUCR,ISC01);
                }
            else if (ModeNum==FALLING_LEVEL)
                {
                    CLR_BIT(MCUCR,ISC00);
                    SET_BIT(MCUCR,ISC01); 
                }
            else if (ModeNum == RISING_LEVEL)
                {
                    SET_BIT(MCUCR,ISC00);
                    SET_BIT(MCUCR,ISC01); 
                }
            break;
        case INT1_PIN:
        DIO_setPinDir(D, PIN2 , input);
        	if(ModeNum==LOW_LEVEL)
                {   CLR_BIT(MCUCR,ISC10);
                    CLR_BIT(MCUCR,ISC11);
                }
            else if (ModeNum==ANY_LOGICAL_LEVEL)
                {
                    SET_BIT(MCUCR,ISC10);
                    CLR_BIT(MCUCR,ISC11);
                }
            else if (ModeNum==FALLING_LEVEL)
                {
                    CLR_BIT(MCUCR,ISC10);
                    SET_BIT(MCUCR,ISC11); 
                }
            else if(ModeNum==RISING_LEVEL)
                {
                    SET_BIT(MCUCR,ISC10);
                    SET_BIT(MCUCR,ISC11); 
                }
                break;
        case INT2_PIN:
        DIO_setPinDir(B, PIN2 , input);
        
        	if (ModeNum==FALLING_LEVEL)
                {
                    CLR_BIT(MCUCSR,ISC2);
                    
                }
        	else if (ModeNum==RISING_LEVEL)
                {
                
                    SET_BIT(MCUCSR,ISC2); 
                }
                break;
    }  
} 
void EXTI_SETCB(u8 IntPinNum ,void(*CBFUN)(void) )
{
     switch(IntPinNum)
        {
          case INT0_PIN:
            CB_INT0=CBFUN;
            break;
            case INT1_PIN:
            CB_INT1=CBFUN;
            break;
            case INT2_PIN:
            CB_INT2=CBFUN;
            break;
        }
}
 ISR (INT0_vect)
    {
        (*CB_INT0)();
    }
 ISR (INT1_vect)
    {
        (*CB_INT1)();
    }
 ISR (INT2_vect)
    {
        (*CB_INT2)();
    }


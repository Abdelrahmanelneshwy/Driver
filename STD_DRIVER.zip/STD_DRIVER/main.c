/*
 * main.c
 *
 *  Created on: Sep 4, 2022
 *      Author: Abdelrahman
 */


#include "HAL/HAL_LCD/LCD_interface.h"
#include "MCAL/MCAL_ADC/ADC_interface.h"

int main()
{
	LCD_init();
	ADC_init(LSB,external,128);
	LCD_Sentence("temp:", 0, 0);
	float temp,x;
	while(1)
	{
		x = ADC_ReadChannel(ADC0);
		temp = ((5*x)/1024)*100;
		LCD_Goto(0,5);
		LCD_Digit(temp);
		LCD_Data('C');
	}
}











/*
#include "HAL/HAL_LCD/LCD_interface.h"
#include "HAL/HAL_EEPROM/EEPROM_interface.h"
#include "MCAL/MCAL_TWI/TWI_interface.h"
#include<util/delay.h>


int main()
{
	EEPROM_init();
	LCD_init();
	LCD_Sentence("test: ", 0, 0);
	EEPROM_WRITE(0x0010,'5');
	u8 Data;
	while(1)
	{
		EEPROM_READ(0x0010, &Data);
		LCD_Goto(0,7);
		LCD_Data(Data);
	}
}*/


/*
#include "HAL/HAL_LCD/LCD_interface.h"
#include<util/delay.h>
#include "MCAL/MCAL_ADC/ADC_interface.h"
#include "MCAL/MCAL_SPI/SPI.h"

int main()
{

	LCD_init();
	LCD_Sentence("data: ", 0, 0);
	SPI_initSlave();
	u8 Data[30];
	while(1)
	{
		SPI_ReceiveString(Data);
		LCD_Sentence("stay safe", 0, 6);
	}
}*/

